import boto3
import csv
import io
import json
from collections import defaultdict
from datetime import datetime

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    sqs = boto3.client('sqs')
    bucket = event['bucket']
    key = event['key']
    hour = event['hour']
    queue_url = event['queue_url']

    try:
        # Pobranie pliku z S3
        response = s3.get_object(Bucket=bucket, Key=key)
        content = response['Body'].read().decode('utf-8')
        
        if not content.strip():  # Sprawdzenie, czy plik jest pusty
            raise ValueError("Plik jest pusty.")

        reader = csv.DictReader(io.StringIO(content))

        # Sprawdzenie, czy wymagane kolumny istnieją w pliku
        required_columns = ['timestamp', 'location_id']
        for column in required_columns:
            if column not in reader.fieldnames:
                raise ValueError(f"Brak wymaganej kolumny: {column}")
        
        grouped = defaultdict(list)
        
        # Przetwarzanie wierszy
        for row in reader:
            timestamp = row.get('timestamp', None)
            
            if not timestamp:
                raise ValueError(f"Brak timestamp w wierszu: {row}")
            
            try:
                # Sprawdzamy, czy timestamp ma poprawny format (pełny format daty i godziny)
                timestamp_obj = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')  # Poprawiony format
            except ValueError:
                raise ValueError(f"Nieprawidłowy format timestamp w wierszu: {row}")
            
            # Jeśli 'timestamp' nie zaczyna się od wymaganej godziny, pomijamy wiersz
            if not timestamp.startswith(hour):
                continue
            
            # Weryfikacja, czy 'location_id' jest obecne
            if 'location_id' not in row or not row['location_id']:
                raise ValueError(f"Brak location_id w wierszu: {row}")
            
            grouped[row['location_id']].append(row)
        
        count = 0
        for loc_id, rows in grouped.items():
            sqs.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps({
                    "location_id": loc_id,
                    "data": rows
                })
            )
            count += 1

        return {
            "chunks": [{} for _ in range(count)]
        }

    except ValueError as e:
        # Obsługa błędów związanych z walidacją danych
        return {
            "statusCode": 400,
            "error": str(e)
        }
    
    except Exception as e:
        # Obsługa innych błędów
        return {
            "statusCode": 500,
            "error": f"Wystąpił błąd: {str(e)}"
        }
